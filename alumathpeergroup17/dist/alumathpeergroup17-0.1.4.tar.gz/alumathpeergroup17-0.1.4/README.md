# alumathpeergroup17

A lightweight Python library for basic matrix computations (addition, subtraction, multiplication) with dimension checks.

## Installation

```bash
pip install alumathpeergroup17
```

from alumathpeergroup17 import matrix_multiplication

a = [[1, 2], [3, 4]]
b = [[5, 6], [7, 8]]

print(matrix_multiplication(a, b))

---

### ✅ **Step 4: Add a `LICENSE` file**

Use an open-source license like MIT. Here's a simple MIT license placeholder:
